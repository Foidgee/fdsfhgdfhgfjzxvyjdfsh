document.addEventListener('DOMContentLoaded', function() {
            const featureModal = document.getElementById('featureModal');
            const modalClose = document.getElementById('modalClose');
            const featureListButton = document.querySelector('.btn-secondary');
            
            if (featureListButton && featureModal && modalClose) {
                featureListButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.body.style.overflow = 'hidden';
                    featureModal.classList.add('active');
                });
                
                modalClose.addEventListener('click', function() {
                    document.body.style.overflow = '';
                    featureModal.classList.remove('active');
                });
                
                featureModal.addEventListener('click', function(e) {
                    if (e.target === featureModal) {
                        document.body.style.overflow = '';
                        featureModal.classList.remove('active');
                    }
                });
            }
            
            const scrollTopBtn = document.getElementById('scrollTop');
            
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    scrollTopBtn.classList.add('visible');
                } else {
                    scrollTopBtn.classList.remove('visible');
                }
            });
            
            scrollTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
            
            const faqQuestions = document.querySelectorAll('.faq-question');
            
            faqQuestions.forEach(question => {
                question.addEventListener('click', function() {
                    const answer = this.nextElementSibling;
                    const isOpen = this.classList.contains('active');
                    
                    faqQuestions.forEach(q => {
                        if (q !== this && q.classList.contains('active')) {
                            q.classList.remove('active');
                            q.nextElementSibling.classList.remove('active');
                        }
                    });
                    
                    if (isOpen) {
                        this.classList.remove('active');
                        answer.classList.remove('active');
                    } else {
                        this.classList.add('active');
                        answer.classList.add('active');
                    }
                });
            });
            
            const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
            const nav = document.querySelector('nav');
            
            if (mobileMenuBtn && nav) {
                mobileMenuBtn.addEventListener('click', function() {
                    nav.classList.toggle('active');
                    this.classList.toggle('active');
                });
                
                const navLinks = document.querySelectorAll('nav a');
                navLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        if (window.innerWidth <= 768) {
                            nav.classList.remove('active');
                            mobileMenuBtn.classList.remove('active');
                        }
                    });
                });
            }
            
            const uiImageContainer = document.querySelector('.ui-image-container');
            
            if (uiImageContainer) {
                let targetRotateX = 0;
                let targetRotateY = 0;
                let currentRotateX = 0;
                let currentRotateY = 0;
                
                uiImageContainer.addEventListener('mousemove', (e) => {
                    const boundingRect = uiImageContainer.getBoundingClientRect();
                    const centerX = boundingRect.width / 2;
                    const centerY = boundingRect.height / 2;
                    const mouseX = e.clientX - boundingRect.left;
                    const mouseY = e.clientY - boundingRect.top;
                    
                    targetRotateX = (centerY - mouseY) / 60;
                    targetRotateY = (mouseX - centerX) / 60;
                });
                
                uiImageContainer.addEventListener('mouseleave', () => {
                    targetRotateX = 0;
                    targetRotateY = 0;
                });
                
                function animateTilt() {
                    const easing = 0.1; 
                    
                    currentRotateX += (targetRotateX - currentRotateX) * easing;
                    currentRotateY += (targetRotateY - currentRotateY) * easing;
                    
                    const rotateX = Math.round(currentRotateX * 100) / 100;
                    const rotateY = Math.round(currentRotateY * 100) / 100;
                    
                    uiImageContainer.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
                    
                    requestAnimationFrame(animateTilt);
                }
                
                animateTilt();
                
                uiImageContainer.addEventListener('mousemove', (e) => {
                    createParticle(e, uiImageContainer);
                });
                
                function createParticle(e, parent) {
                    const boundingRect = parent.getBoundingClientRect();
                    const x = e.clientX - boundingRect.left;
                    const y = e.clientY - boundingRect.top;
                    
                    if (Math.random() > 0.85) {  
                        const particle = document.createElement('div');
                        particle.className = 'particle';
                        
                        const randomOffset = () => (Math.random() - 0.5) * 20;
                        particle.style.left = `${x + randomOffset()}px`;
                        particle.style.top = `${y + randomOffset()}px`;
                        
                        const size = 2 + Math.random() * 4;
                        particle.style.width = `${size}px`;
                        particle.style.height = `${size}px`;
                        
                        const hue = Math.random() * 30 - 15; 
                        particle.style.backgroundColor = `hsl(var(--accent-hue, 250) ${hue}deg, 70%, 70%)`;
                        
                        parent.appendChild(particle);
                        
                        const angle = Math.random() * Math.PI * 2;
                        const velocity = 2 + Math.random() * 4;
                        const lifetime = 1000 + Math.random() * 1000;
                        let progress = 0;
                        
                        const animateParticle = () => {
                            if (progress >= lifetime) {
                                particle.remove();
                                return;
                            }
                            
                            progress += 16; 
                            const percent = progress / lifetime;
                            
                            const moveX = x + Math.cos(angle) * velocity * percent * 40;
                            const moveY = y + Math.sin(angle) * velocity * percent * 40;
                            const opacity = 1 - percent;
                            
                            particle.style.left = `${moveX}px`;
                            particle.style.top = `${moveY}px`;
                            particle.style.opacity = opacity;
                            
                            requestAnimationFrame(animateParticle);
                        };
                        
                        requestAnimationFrame(animateParticle);
                    }
                }
            }
        });


document.addEventListener("DOMContentLoaded", () => {
    const keyBtn = document.getElementById("getKeyBtn");

    if (keyBtn) {
        keyBtn.addEventListener("click", () => {
            const key = 'chatware-9420012';
            
            // Copiar al portapapeles
            navigator.clipboard.writeText(key).then(() => {
                // Mostrar notificación

            }).catch(err => {

            });
        });
    }
});
